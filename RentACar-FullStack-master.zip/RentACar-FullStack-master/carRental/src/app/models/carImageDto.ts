export interface CarImageDto {
    id:number;
    carId:number;
    imagePath:string;
    date:Date;
    image:File
}