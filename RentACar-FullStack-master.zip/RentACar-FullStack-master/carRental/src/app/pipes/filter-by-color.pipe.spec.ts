import { FilterByColorPipe } from './filter-by-color.pipe';

describe('FilterByColorPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByColorPipe();
    expect(pipe).toBeTruthy();
  });
});
