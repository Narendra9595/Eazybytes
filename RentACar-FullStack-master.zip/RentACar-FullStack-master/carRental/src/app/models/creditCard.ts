export interface CreditCard{
    id:number;
    customerId:number;
    ccNumber:string;
    nameOnCard:string;
    expirationMonth:string;
    expirationYear:string;
    cvv:string;
}