import { FilterByCarTypePipe } from './filter-by-car-type.pipe';

describe('FilterByCarTypePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByCarTypePipe();
    expect(pipe).toBeTruthy();
  });
});
