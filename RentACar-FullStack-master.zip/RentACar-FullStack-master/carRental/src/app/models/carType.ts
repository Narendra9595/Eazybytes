export interface CarType{
    id:number;
    name:string;
}