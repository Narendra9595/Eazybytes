import { FilterByMultiplePipe } from './filter-by-multiple.pipe';

describe('FilterByMultiplePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByMultiplePipe();
    expect(pipe).toBeTruthy();
  });
});
