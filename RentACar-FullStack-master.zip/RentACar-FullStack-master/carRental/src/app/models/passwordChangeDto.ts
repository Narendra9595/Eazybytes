export interface PasswordChangeDto{
    id:number;
    password:string;
}