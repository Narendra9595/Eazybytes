export interface Color{
    id:number;
    name:string;
}