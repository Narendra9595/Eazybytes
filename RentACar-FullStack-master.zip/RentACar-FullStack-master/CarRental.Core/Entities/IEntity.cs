﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRental.Core.Entities
{
    public interface IEntity
    {
    }
}
