export interface Brand{
    id:number;
    name:string;
}