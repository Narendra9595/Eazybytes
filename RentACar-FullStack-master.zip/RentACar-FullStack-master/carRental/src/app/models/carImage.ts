export interface CarImage {
    id:number;
    carId:number;
    imagePath:string;
    date:Date;
}