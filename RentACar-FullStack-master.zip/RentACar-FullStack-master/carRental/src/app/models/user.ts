export interface User{
    id:number;
    userName:number;
    email:string;
    password:string;
}